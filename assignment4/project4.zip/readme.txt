Please follow:

mkdir build
cd build
camke ..
make